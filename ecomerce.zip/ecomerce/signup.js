document.addEventListener("DOMContentLoaded", function() {

    const form = document.getElementById("signup-form");

    const confirmation = document.getElementById("confirmation");

 

    form.addEventListener("submit", function(event) {

        event.preventDefault();

 

        const name = document.getElementById("name").value;


const email = document.getElementById("email").value;

const password = document.getElementById("password").value;


        if (name && email && password) {

            // Send the form data to a server or perform other actions here

            // For this example, we'll display a confirmation message

            confirmation.innerText = "You are successfully Signup. We will get back to you Soon.";

            form.reset();

        } else {

            confirmation.innerText = "Please fill in all the fields.";

        }

    });

});